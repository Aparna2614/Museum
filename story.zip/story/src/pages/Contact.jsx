import React from 'react'
import BreadCrumbs from '../components/BreadCrumbs';
function Contact() {
  return (
    <div>
      {/* breadcrumb */}
      <BreadCrumbs page="Contact us" title="Contact Company"/>
    {/*//breadcrumb*/}
    {/* contact1 */}
    <section className="w3l-contact-1 py-5" id="contact">
        <div className="contacts-9 py-lg-5 py-md-4">
            <div className="container">
                <div className="contactct-fm map-content-9">
                    <div className="header-title text-center">
                        <h6 className="title-subhny"><span>contact Us</span></h6>
                        <h3 className="title-w3l mb-2">Let’s Talk About
                            <span className="span-bold"> Your Project</span>
                        </h3>
                        <p className="mb-sm-5 mb-4">Start working with Us that can provide everything you need to generate awareness,
                            drive traffic,
                            connect. <br/> We guarantee that you’ll be able to have any issue resolved within 24 hours.</p>
                    </div>
                    <form action="https://sendmail.w3layouts.com/submitForm" className="pt-lg-4" method="post">
                        <div className="twice-two">
                            <input type="text" className="form-control" name="w3lName" id="w3lName" placeholder="Name" required=""/>
                            <input type="email" className="form-control" name="w3lSender" id="w3lSender" placeholder="Email" required=""/>
                        </div>
                        <div className="twice-two">
                            <input type="text" className="form-control" name="w3lPhone" id="w3lPhone" placeholder="Phone" required=""/>
                            <input type="text" className="form-control" name="w3lSubject" id="w3lSubject" placeholder="Subject" required=""/>
                        </div>
                        <textarea name="w3lMessage" className="form-control" id="w3lMessage" placeholder="Message" required=""/>
                        <div className="text-lg-center">
                            <button type="submit" className="btn btn-primary btn-style mt-lg-5 mt-4">Send Message</button>
                        </div>
                    </form>
                </div>
                <div className="row contact-view my-5 py-lg-5">
                    <div className="col-lg-6 cont-details">
                        <div className="contactct-fm-text text-left">
                            <h6 className="title-subhny"><span>Find Us</span></h6>
                            <h3 className="title-w3l mb-5">London
                                <span className="span-bold"> Office</span>
                            </h3>
                            <div className="cont-top">
                                <div className="cont-left text-center">
                                    <span className="fas fa-phone-alt"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Phone number</h5>
                                    <p><a href="tel:+(21) 255 088 4943">+(21) 255 088 4943</a></p>
                                </div>
                            </div>
                            <div className="cont-top margin-up">
                                <div className="cont-left text-center">
                                    <span className="fas fa-envelope-open-text"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Send Email</h5>
                                    <p><a href="mailto:kodeal@mail.com" className="mail">kodeal@mail.com</a></p>
                                </div>
                            </div>
                            <div className="cont-top margin-up">
                                <div className="cont-left text-center">
                                    <span className="fas fa-map-marker-alt"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Office Address</h5>
                                    <p className="pr-lg-5">Address here, 434 Food Honey street,<br/> London, UK - 62617.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 cont-details mt-lg-0 mt-5">
                        <div className="contactct-fm-text text-left">
                            <h6 className="title-subhny"><span>Find Us</span></h6>
                            <h3 className="title-w3l mb-5">Newyork
                                <span className="span-bold"> Office</span>
                            </h3>
                            <div className="cont-top">
                                <div className="cont-left text-center">
                                    <span className="fas fa-phone-alt"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Phone number</h5>
                                    <p><a href="tel:+(21) 255 088 4943">+(21) 255 088 4943</a></p>
                                </div>
                            </div>
                            <div className="cont-top margin-up">
                                <div className="cont-left text-center">
                                    <span className="fas fa-envelope-open-text"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Send Email</h5>
                                    <p><a href="mailto:kodeal@mail.com" className="mail">kodeal@mail.com</a></p>
                                </div>
                            </div>
                            <div className="cont-top margin-up">
                                <div className="cont-left text-center">
                                    <span className="fas fa-map-marker-alt"></span>
                                </div>
                                <div className="cont-right">
                                    <h5>Office Address</h5>
                                    <p className="pr-lg-5">Address here, 434 Food Honey street,<br/> London, UK - 62617.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="map-content-9">
    <div className="map-iframe">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d107416.56350857!2d74.79793285820311!3d32.718802400000015!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391e849955a0d7cf%3A0x1a5dc7b412505c64!2sUniversity%20of%20Jammu!5e0!3m2!1sen!2sin!4v1712927578983!5m2!1sen!2sin" width="600" height="450" style={{ border: '0' }} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div>
            </div>
        </div>
    </section>
    {/* /contact1 */}
    </div>
  )
}

export default Contact;

