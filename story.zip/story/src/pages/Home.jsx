import React, { useState, useEffect } from 'react';

export default function Home() {
return (
    <>
    
{/* Header */}
{/* main-slider */}
<section className="w3l-main-slider banner-slider" id="home">
    <div className="owl-one owl-carousel owl-theme">
        <div className="item">
            <div className="slider-info banner-view banner-top1">
                <div className="container">
                    <div className="banner-info">
                        <h3>A Virtual Museum Tour <span> Partition Era</span></h3>
                        <div className="banner-info-top">
                            <p>Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                            <a href="about.html" className="btn btn-style btn-outline-light mt-sm-5 mt-4">Read More <span className="fas fa-angle-double-right ms-2"></span> </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>
{/* /main-slider */}
{/*/bottom-3-grids*/}
<div className="w3l-3-grids" id="grids-3">
    <div className="container-fluid mx-lg-0">
        <div className="row pt-sm-0 pt-5">
            <div className="col-lg-4 col-sm-6 mt-sm-0 m px-md-0 w3-gridhny-1 position-relative">
                <div className="grids3-info">
                    <a href="#" className="d-block zoom"><img src="assets/images/bgimg.png" alt="" className="img-fluid news-image"/></a>
                    <div className="w3-grids3-info">
                        <h6><a href="#category" className="category d-block">Action</a></h6>
                        <h4><a href="#">We have got minds in <span>action</span></a></h4>
                    </div>
                </div>
            </div>
            <div className="col-lg-4 col-sm-6 mt-sm-0 px-md-0 w3-gridhny-1 position-relative">
                <div className="grids3-info">
                    <a href="#blog" className="d-block zoom"><img src="assets/images/pic.webp" alt="" className="img-fluid news-image"/></a>
                    <div className="w3-grids3-info second">
                        <h6><a href="#category" className="category d-block">Brand</a></h6>
                        <h4><a href="#">Plugging ideas to your <span>brand</span></a></h4>

                    </div>
                </div>
            </div>
            <div className="col-lg-4 col-sm-6 mt-lg-0 px-md-0 w3-gridhny-1 position-relative">
                <div className="grids3-info">
                    <a href="#blog" className="d-block zoom"><img src="assets/images/g3.jpg" alt="" className="img-fluid news-image"/></a>
                    <div className="w3-grids3-info">
                        <h6><a href="#category" className="category d-block">Success</a></h6>
                        <h4><a href="#">Ideas in charge of your <span>Success</span></a></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{/*//bottom-3-grids*/}
{/*/about-section*/}
<section className="w3l-index2" id="about">
    <div className="midd-w3 py-5">
        <div className="container py-md-5 py-3">
            {/*/row-1*/}
            <div className="row">
                <div className="col-lg-6">
                    <div className="w3shape position-relative">
                        <img src="assets/images/ab1.jpg" alt="" className="radius-image img-fluid"/>
                    </div>
                </div>
                <div className="col-lg-6 mt-lg-0 mt-md-5 mt-4 align-self ps-lg-5">
                    <div className="title-content text-left">
                        <h6 className="title-subhny mb-2"><span>Our Story</span></h6>
                        <h3 className="title-w3l">Helping business become what they
                            <span className="span-bold">can be</span>
                        </h3>
                    </div>
                    <p className="mt-md-4 mt-3">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                        ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet
                        elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit amet. Lorem ipsum init
                        dolor sit, amet elit. Dolor ipsum non velit, culpa! Vivamus a et ut justo, init in dolor et.</p>
                    <div className="w3l-two-buttons">
                        <a href="about.html" className="btn btn-style btn-primary mt-lg-5 mt-4">Read More <span className="fas fa-angle-double-right ms-2"></span></a>
                        <a href="#view" className="btn btn-outline-primary btn-style mt-lg-5 mt-4 ms-2"> Contact Us<span className="fas fa-angle-double-right ms-2"></span></a>
                    </div>
                </div>
            </div>
            {/*//row-1*/}

        </div>
    </div>
</section>
{/*//about-section*/}
<section className="w3l-video-sec" id="video">
    <div className="container">
        <div className="w3l-index5 py-5" id="video">
            <div className="history-info align-self text-center py-5 my-lg-5">
                <div className="position-relative py-5 my-lg-5">
                    <a href="#small-dialog1" className="popup-with-zoom-anim play-view text-center position-absolute">
                        <span className="video-play-icon">
                            <span className="fa fa-play"></span>
                        </span>
                    </a>
                    {/* dialog itself, mfp-hide className is required to make dialog hidden --
                    <div id="small-dialog1" className="zoom-anim-dialog mfp-hide">
                        <iframe src="https://player.vimeo.com/video/124801644" frameborder="0" allow="autoplay; fullscreen" allowfullscreen=""></iframe>
                    </div>
                                            {/* dialog itself, mfp-hide className is required to make dialog hidden */}
                </div>
            </div>
        </div>
    </div>
</section>
{/*/grids*/}
<section className="w3l-grids-3 home-page-gds py-5">
    <div className="container py-md-5 py-3">
        <div className="header-sec text-center pt-lg-5 mt-lg-5">
            <h3 className="title-w3l two mb-4 mt-lg-5">We are a young and creative company & we <br/> offer you
                <span className="span-bold">fresh ideas.</span>
            </h3>
        </div>
        <div className="row bottom_grids text-left">
            <div className="col-lg-3 col-md-6 mt-5">
                <div className="grid-block text-center">
                    <a href="#blog" className="d-block p-lg-4 p-3">
                        <span className="fas fa-coins" aria-hidden="true"></span>
                        <h4 className="my-3">Secure Payments</h4>
                        <p className="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                    </a>
                </div>
            </div>
            <div className="col-lg-3 col-md-6 mt-5">
                <div className="grid-block text-center">
                    <a href="#blog" className="d-block p-lg-4 p-3">
                        <span className="fas fa-chart-pie" aria-hidden="true"></span>
                        <h4 className="my-3">Daily Updates</h4>
                        <p className="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                    </a>
                </div>
            </div>
            <div className="col-lg-3 col-md-6 mt-5">
                <div className="grid-block text-center">
                    <a href="#blog" className="d-block p-lg-4 p-3">
                        <span className="fas fa-bullhorn" aria-hidden="true"></span>
                        <h4 className="my-3">Market Research</h4>

                        <p className="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                    </a>
                </div>
            </div>
            <div className="col-lg-3 col-md-6 mt-5">
                <div className="grid-block text-center">
                    <a href="#blog" className="d-block p-lg-4 p-3">
                        <span className="fas fa-headset" aria-hidden="true"></span>
                        <h4 className="my-3">24/7 Support</h4>
                        <p className="">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula. </p>
                    </a>
                </div>
            </div>

        </div>
    </div>
</section>
{/*//grids*/}
{/*/services*/}
<section className="w3l-services2" id="services">
    <div id="cwp23-block" className="py-5">
        <div className="container py-lg-5">
            <div className="row cwp23-content mt-lg-5 mt-4">
                <div className="col-lg-6 cwp23-img">
                    <h6 className="title-subhny mb-2"><span>What We Do?</span></h6>
                    <h3 className="title-w3l mb-4">The service we offer is specifically designed to meet <br/>
                        <span className="span-bold">your needs.</span>
                    </h3>
                    <p className="mt-4">Sed in metus libero. Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                        Morbi ac metus vitae diam scelerisque malesuada eget eu mauris.Cras varius lorem ac velit pharetra.

                    </p>

                    <div className="w3l-button mt-lg-5 mt-4">
                        <a href="services.html" className="btn btn-style btn-primary mt-2">Read More <span className="fas fa-angle-double-right ms-2"></span></a>
                    </div>
                </div>
                <div className="col-lg-6 cwp23-text mt-lg-0 mt-5 ps-lg-5">
                    <div className="cwp23-text-cols">
                        <div className="column">
                            <a href="#"><img src="assets/images/g2.jpg" alt="" className="radius-image img-fluid"/></a>
                        </div>
                        <div className="column">
                            <a href="#"><img src="assets/images/g3.jpg" alt="" className="radius-image img-fluid"/></a>
                        </div>
                        <div className="column">
                            <a href="#"><img src="assets/images/g4.jpg" alt="" className="radius-image img-fluid"/></a>
                        </div>
                        <div className="column">
                            <a href="#"><img src="assets/images/g5.jpg" alt="" className="radius-image img-fluid"/></a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

{/*//services*/}
{/*/w3l-project*/}
<section className="w3l-project-main pb-5">
    <div className="container pb-md-5 py-2">
        <div className="w3l-project p-md-5 p-4 px-4">
            <div className="row py-lg-4 px-lg-2 align-items-center">
                <div className="col-lg-8 w3l-project-right">
                    <div className="bottom-info">
                        <div className="header-section pr-lg-5">
                            <h3 className="title-w3l two">Request Free Consultation <br/>and <span className="span-bold">Lets Do It!</span>
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4 w3l-project-left mt-lg-0 mt-4">
                    <a href="#" className="btn btn-secondary btn-style"> Request Now <span className="fas fa-angle-double-right ms-2"></span></a>
                </div>
            </div>
        </div>
    </div>
</section>
{/*//w3l-project*/}

{/* /features*/}
<section className="w3l-featureshny py-5" id="features">
    <div className="container py-md-4 py-2">
        <div className="row align-items-center">
            <div className="col-lg-8 pe-lg-5 mb-lg-0 mb-5">
                <div className="w3l-header-sec text-left mb-md-5 mb-4">
                    <h6 className="title-subhny mb-2"><span>Creative Strategy</span></h6>
                    <h5 className="">Company that believes in the power of <span className="span-bold">creative strategy</span></h5>
                    <p className="mt-3 pr-lg-5">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.
                        Semper at tempufddfel. Lorem ipsum dolor sit amet elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit
                        amet.Vivamus a et ut justo, init in dolor. </p>
                    <a href="services.html" className="btn btn-primary btn-style mt-lg-5 mt-4"> Read More <span className="fas fa-angle-double-right ms-2"></span></a>
                </div>
            </div>
            <div className="col-lg-4 mb-lg-0 mb-md-5 mb-4">
                <div className="whybox-wrap mb-4">
                    <div className="whybox-wrap-grid">
                        <div className="icon">
                            <span className="fas fa-lightbulb"></span>
                        </div>
                        <div className="info">
                            <h4><a href="#url">Collect Ideas</a></h4>
                            <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="whybox-wrap mb-4">
                    <div className="whybox-wrap-grid">
                        <div className="icon">
                            <span className="fas fa-database"></span>
                        </div>
                        <div className="info">
                            <h4><a href="#url">Data Analysis</a></h4>
                            <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="whybox-wrap">
                    <div className="whybox-wrap-grid">
                        <div className="icon">
                            <span className="fas fa-chart-area"></span>
                        </div>
                        <div className="info">
                            <h4><a href="#url">Finalize Product</a></h4>
                            <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
{/* //features*/}
{/* testimonials */}
<section className="w3l-clients pb-5" id="clients">
    {/* /grids */}
    <div className="cusrtomer-layout py-5 pb-0">
        <div className="container py-lg-4 py-md-3 ">
            <div className="heading text-center mx-auto">
                <h6 className="title-subhny mb-2"><span>Testimonials</span></h6>
                <h3 className="title-w3l mb-5">Happy Clients
                    <span className="span-bold">& Feedbacks</span>
                </h3>
            </div>
            {/* /grids */}
            <div className="testimonial-width">
                <div className="row">
                    <div className="col-lg-6 item">
                        <div className="testimonial-content">
                            <div className="testimonial">
                                <blockquote>
                                    <q><i className="fas fa-quote-left"></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae
                                        laudantium
                                        voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                                        Dolores molestias adipisci dolor sit amet!.</q>
                                </blockquote>
                                <div className="testi-des">
                                    <div className="test-img"><img src="assets/images/team1.jpg" className="img-fluid" alt="client-img"/>
                                    </div>
                                    <div className="peopl align-self">
                                        <h3>John wilson</h3>
                                        <p className="indentity">Example City</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-6 item">
                        <div className="testimonial-content">
                            <div className="testimonial">
                                <blockquote>
                                    <q><i className="fas fa-quote-left"></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae
                                        laudantium
                                        voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                                        Dolores molestias adipisci dolor sit amet!.</q>
                                </blockquote>
                                <div className="testi-des">
                                    <div className="test-img"><img src="assets/images/team2.jpg" className="img-fluid" alt="client-img"/>
                                    </div>
                                    <div className="peopl align-self">
                                        <h3>Julia sakura</h3>
                                        <p className="indentity">Example City</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
        {/* /grids */}
    </div>
    {/* //grids */}
</section>
{/* //testimonials */}
  </>
  )
}