import React from 'react'
import BreadCrumbs from '../components/BreadCrumbs'

function About() {
  return (
    <>
      {/* Breadcrumb */}
      <BreadCrumbs page="About us" title="About Virtual Museum"/>
      {/* //Breadcrumb */}
      
      {/* Services */}
      <section className="w3l-feature-with-photo-1">
        <div className="feature-with-photo-hny py-5">
            <div className="container py-lg-5">
                <div className="feature-with-photo-content">
                    <div className="ab-in-flow row mb-lg-5 mb-3">
                        <div className="col-lg-6 ab-left pe-lg-5">
                            <img src="assets/images/ab2.jpg" className="img-fluid radius-image" alt=""/>
                        </div>
                        <div className="col-lg-6 ab-right pl-lg-5">
                            <h6 className="title-subhny mb-2"><span>About Us</span></h6>
                            <h3 className="title-w3l mb-4">We are a young and creative company and we offer you fresh
                                <span className="span-bold">business ideas.</span>
                            </h3>
                            <p className="my-4">Excepteur sint occaecat non proident, sunt in culpa quis. Phasellus lacinia
                                id
                                erat eu ullamcorper. Nunc id ipsum fringilla,
                                gravida felis vitae. Phasellus lacinia id, sunt in culpa quis. Phasellus lacinia Excepteur sint occaecat
                                non proident, sunt in culpa quis.</p>

                            <a href="services.html" className="btn btn-style btn-primary mt-2">Read More <span className="fas fa-angle-double-right ml-2"></span></a>
                        </div>
                    </div>
                    <div className="three-grids d-grid grid-columns-3 mt-lg-5 pt-lg-4">
                        <div className="grid">
                            <h3 className="title-w3l mb-4">What we
                                <span className="span-bold"> Do ?.</span>
                            </h3>
                        </div>
                        <div className="grid">
                            <div className="three-grids-icon">
                                1
                            </div>
                            <h4><a href="#">Our Vision</a></h4>
                            <p>Phasellus lacinia id
                                erat eu ullamcorper. Nunc id ipsum fringilla.</p>
                        </div>
                        <div className="grid">
                            <div className="three-grids-icon">
                                2
                            </div>
                            <h4><a href="#">Our Mission</a></h4>
                            <p>Phasellus lacinia id
                                erat eu ullamcorper. Nunc id ipsum fringilla.</p>
                        </div>
                        <div className="grid">
                            <div className="three-grids-icon">
                                3
                            </div>
                            <h4><a href="#">Our Values</a></h4>
                            <p>Phasellus lacinia id
                                erat eu ullamcorper. Nunc id ipsum fringilla.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* //feature with photo1 */}
    {/* /features*/}
    <section className="w3l-featureshny py-5" id="features">
        <div className="container py-md-4 py-2">
            <div className="row align-items-center">
                <div className="col-lg-8 pe-lg-5 mb-lg-0 mb-5">
                    <div className="w3l-header-sec text-left mb-md-5 mb-4">
                        <h6 className="title-subhny mb-2"><span>Who We Are</span></h6>
                        <h5 className="">The operational processes are what drives <span className="span-bold">the business </span></h5>
                        <p className="mt-3 pr-lg-5">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo, ultrices in ligula.
                            Semper at tempufddfel. Lorem ipsum dolor sit amet elit. Non quae, fugiat nihil ad. Lorem ipsum dolor sit
                            amet.Vivamus a et ut justo, init in dolor. </p>
                        <a href="services.html" className="btn btn-primary btn-style mt-lg-5 mt-4"> Read More <span className="fas fa-angle-double-right ms-2"></span></a>
                    </div>
                </div>
                <div className="col-lg-4 mb-lg-0 mb-md-5 mb-4">
                    <div className="whybox-wrap mb-4">
                        <div className="whybox-wrap-grid">
                            <div className="icon">
                                <span className="fas fa-lightbulb"></span>
                            </div>
                            <div className="info">
                                <h4><a href="#url">Collect Ideas</a></h4>
                                <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="whybox-wrap mb-4">
                        <div className="whybox-wrap-grid">
                            <div className="icon">
                                <span className="fas fa-database"></span>
                            </div>
                            <div className="info">
                                <h4><a href="#url">Data Analysis</a></h4>
                                <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="whybox-wrap">
                        <div className="whybox-wrap-grid">
                            <div className="icon">
                                <span className="fas fa-chart-area"></span>
                            </div>
                            <div className="info">
                                <h4><a href="#url">Finalize Product</a></h4>
                                <p className="mt-3">Lorem ipsum dolor sit amet consectetur ipsum amet elit.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    {/* //features*/}
    {/*/team-sec*/}
    <section className="w3l-team-main team py-5" id="team">
        <div className="container py-lg-5">
            <div className="w3l-heaser-sec text-center">
                <h6 className="title-subhny mb-2"><span>Passionate team.</span></h6>
                <h3 className="title-w3l mb-4">Creative Minds Always
                    <span className="span-bold">Think Someting .</span>
                </h3>
            </div>
            <div className="row team-row mt-md-5 mt-4">
                <div className="col-lg-3 col-6 team-wrap">
                    <div className="team-member text-center">
                        <div className="team-img">
                            <img src="assets/images/team1.jpg" alt="" className="radius-image"/>
                            <div className="overlay-team">
                                <div className="team-details text-center">
                                    <div className="socials mt-20">
                                        <a href="#url">
                                            <span className="fab fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-linkedin-in"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" className="team-title">Luke jacobs</a>
                        <p>Founder</p>
                    </div>
                </div>
                {/* end team member */}
                <div className="col-lg-3 col-6 team-wrap">
                    <div className="team-member text-center">
                        <div className="team-img">
                            <img src="assets/images/team3.jpg" alt="" className="radius-image"/>
                            <div className="overlay-team">
                                <div className="team-details text-center">
                                    <div className="socials mt-20">
                                        <a href="#url">
                                            <span className="fab fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-linkedin-in"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" className="team-title">Claire olson</a>
                        <p>Manager</p>
                    </div>
                </div>
                {/* end team member */}
                <div className="col-lg-3 col-6 team-wrap mt-lg-0 mt-5">
                    <div className="team-member last text-center">
                        <div className="team-img">
                            <img src="assets/images/team2.jpg" alt="" className="radius-image"/>
                            <div className="overlay-team">
                                <div className="team-details text-center">
                                    <div className="socials mt-20">
                                        <a href="#url">
                                            <span className="fab fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-linkedin-in"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" className="team-title">Phillip hunt</a>
                        <p>Advisor</p>
                    </div>
                </div>
                {/* end team member */}
                <div className="col-lg-3 col-6 team-wrap mt-lg-0 mt-5">
                    <div className="team-member last text-center">
                        <div className="team-img">
                            <img src="assets/images/team4.jpg" alt="" className="radius-image"/>
                            <div className="overlay-team">
                                <div className="team-details text-center">
                                    <div className="socials mt-20">
                                        <a href="#url">
                                            <span className="fab fa-facebook-f"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-twitter"></span>
                                        </a>
                                        <a href="#url">
                                            <span className="fab fa-linkedin-in"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#url" className="team-title">Sara grant</a>
                        <p>HR </p>
                    </div>
                </div>
                {/* end team member */}
            </div>
        </div>
    </section>
    {/*//team-sec*/}
    {/*/w3l-project*/}
    <section className="w3l-project-main pb-5">
        <div className="container pb-md-5 -b-3">
            <div className="w3l-project p-md-5 p-4 px-4">
                <div className="row py-lg-4 px-lg-2 align-items-center">
                    <div className="col-lg-8 w3l-project-right">
                        <div className="bottom-info">
                            <div className="header-section pr-lg-5">
                                <h3 className="title-w3l two">Request Free Consultation <br/>and <span className="span-bold">Lets Do It!</span>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 w3l-project-left mt-lg-0 mt-4">
                        <a href="#" className="btn btn-secondary btn-style"> Contact Now <span className="fas fa-angle-double-right ms-2"></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </>
  )
}
export default About
