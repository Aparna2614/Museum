import React from 'react';
import BreadCrumbs from '../components/BreadCrumbs';
export default function Images() {
  return (
    <>
    
    {/* breadcrumb */}
    <BreadCrumbs page="VIDEO TOUR" title="Explore the Unsaid Stories"/>
    {/* services */}
    <section className="w3l-services2" id="services">
      <div id="cwp23-block" className="py-5">
        <div className="container py-lg-5">
          <div className="row cwp23-content mt-lg-5 mt-4">
            <div className="col-lg-6 cwp23-img">
              <h6 className="title-subhny mb-2"><span>What We Do?</span></h6>
              <h3 className="title-w3l mb-4">The service we offer is specifically designed to meet <br />
                <span className="span-bold">your needs.</span>
              </h3>
              <p className="mt-4">Sed in metus libero. Sed volutpat eget dui ut tempus. Fusce fringilla tincidunt laoreet
                Morbi ac metus vitae diam scelerisque malesuada eget eu mauris.Cras varius lorem ac velit pharetra.

              </p>
              <div className="w3l-button mt-lg-5 mt-4">
                <a href="services.html" className="btn btn-style btn-primary mt-2">Read More <span className="fas fa-angle-double-right ms-2"></span></a>
              </div>
            </div>
            <div className="col-lg-6 cwp23-text mt-lg-0 mt-5 ps-lg-5">
              <div className="cwp23-text-cols">
                <div className="column">
                  <a href="#"><img src="assets/images/g2.jpg" alt="" className="radius-image img-fluid" /></a>
                </div>
                <div className="column">
                  <a href="#"><img src="assets/images/g3.jpg" alt="" className="radius-image img-fluid" /></a>
                </div>
                <div className="column">
                  <a href="#"><img src="assets/images/g4.jpg" alt="" className="radius-image img-fluid" /></a>
                </div>
                <div className="column">
                  <a href="#"><img src="assets/images/g5.jpg" alt="" className="radius-image img-fluid" /></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* grids */}
    <section className="w3l-grids-3 py-5">
      <div className="container py-md-5 py-3">
        <div className="row bottom-ab-grids align-items-center">
          <div className="header-sec text-center">
            <h6 className="title-subhny mb-2"><span>How We Do It?</span></h6>
            <h3 className="title-w3l mb-3">We Are A Young And Creative Company & We<br />
              Offer You
              <span className="span-bold">Fresh Ideas.</span>
            </h3>
          </div>
        </div>
        <div className="row bottom_grids pt-md-3 text-left">
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fas fa-file-alt" aria-hidden="true"></span>
                <h4 className="my-3">Concept</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fas fa-holly-berry" aria-hidden="true"></span>
                <h4 className="my-3">Prepare</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fas fa-american-sign-language-interpreting" aria-hidden="true"></span>
                <h4 className="my-3">Retouch</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fa fa-cubes" aria-hidden="true"></span>
                <h4 className="my-3">Finalize</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fas fa-chart-pie" aria-hidden="true"></span>
                <h4 className="my-3">Daily Updates</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 mt-5">
            <div className="grid-block">
              <a href="#blog" className="d-block p-lg-4 p-3">
                <span className="fas fa-headset" aria-hidden="true"></span>
                <h4 className="my-3">24/7 Support</h4>
                <p className="">Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* services3 */}
    
    {/* pricing */}
    <section className="w3l-pricing-sec py-5" id="pricing">
      <div className="container py-md-5 py-2">
        <div className="title-content text-center">
          <h6 className="title-subhny mb-2"><span>Get Started</span></h6>
          <h3 className="title-w3l mb-4">story
            <span className="span-bold">-Interview</span>
          </h3>
        </div>
        <div className="row pricing-main-grids mt-3">
          <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
            <div className="w3-pricing-inner-inf">
              <div className="pricing-header">
                <h4>Basic</h4>
                <p>A beautiful, simple website</p>
                <div className="price-wrapper mt-4">
                  <div className="price">
                    <h3 className="currency">From $</h3>
                    <h3 className="heading headin-h3">39</h3>
                  </div>
                </div>
              </div>
              <div className="pricing-body">
                <div className="inner">
                  <ul className="list-style">
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 5 Projects</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 2100K API Access</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 200MB Storag</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> Weekly Reports</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 24/7 Support</li>
                  </ul>
                </div>
                <div className="pricing-get-button mt-3">
                  <a className="btn btn-secondary btn-style mt-4 d-block" href="#">Get Started
                    Today </a>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
            <div className="w3-pricing-inner-inf">
              <div className="pricing-header set-2">
                <h4>Standard</h4>
                <p>A beautiful, simple website</p>
                <div className="price-wrapper mt-4">
                  <div className="price">
                    <h3 className="currency">From $</h3>
                    <h3 className="heading headin-h3">69</h3>
                  </div>
                </div>
              </div>
              <div className="pricing-body">
                <div className="inner">
                  <ul className="list-style">
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 10 Projects</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 2100K API Access</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 300MB Storag</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> Weekly Reports</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 24/7 Support</li>
                  </ul>
                </div>
                <div className="pricing-get-button mt-3">
                  <a className="btn btn-secondary btn-style mt-4 d-block" href="#">Get Started
                    Today </a>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6 pricing-main-grid mt-sm-5 mt-4">
            <div className="w3-pricing-inner-inf">
              <div className="pricing-header set-3">
                <h4>Premium Plan</h4>
                <p>A beautiful, simple website</p>
                <div className="price-wrapper mt-4">
                  <div className="price">
                    <h3 className="currency">From $</h3>
                    <h3 className="heading headin-h3">99</h3>
                  </div>
                </div>
              </div>
              <div className="pricing-body">
                <div className="inner">
                  <ul className="list-style">
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 15 Projects</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 2100K API Access</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> 400MB Storag</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span> Weekly Reports</li>
                    <li><span className="fa fa-check me-2" aria-hidden="true"></span>24/7 Support</li>
                  </ul>
                </div>
                <div className="pricing-get-button mt-3">
                  <a className="btn btn-secondary btn-style mt-4 d-block" href="#">Get Started
                    Today </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    {/* w3l-footer-29-main */}
    
    {/* move top */}
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span className="fas fa-long-arrow-up"></span>
    </button>
    </>
  )
}
  
