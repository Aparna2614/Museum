import React from 'react'
import About from './pages/About'
import Contact from './pages/Contact'
import Home from './pages/Home'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Images from './pages/Images'
import Videos from './pages/Videos'
import Audios from './pages/Audios'
function App() {
  return (
    <div>
      <Header/>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/images' element={<Images/>}/>
      <Route path='/videos' element={<Videos/>}/>
      <Route path='/audios' element={<Audios/>}/>
      <Route path='/about' element={<About/>}/>
      <Route path='/contact' element={<Contact/>}/>
      
      </Routes></BrowserRouter>
      <Footer/>
  </div>
  )
}

export default App