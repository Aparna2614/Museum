import React from 'react'

function Header() {
  return (
    <>
    <header id="site-header" className="fixed-top">
        <div className="container">
            <nav className="navbar navbar-expand-lg navbar-light stroke py-lg-0">
                <h1><a className="navbar-brand pe-xl-5 pe-lg-4" href="index.html">
                        T<span className="sublog">he</span><hr/>
                        S<span className="sublog">tory</span>
                        T<span className="sublog">elling</span>
                        M<span className="sublog">useum</span>
                    </a></h1>
                <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                    <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarScroll">
                    <ul className="navbar-nav me-lg-auto my-2 my-lg-0 navbar-nav-scroll">
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="/">Home</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/images">Images</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/videos">Videos</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/audios">Audios</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="/about">About</a>
                        </li>
                    
                        <li className="nav-item">
                            <a className="nav-link" href="/contact">Contact</a>
                        </li>

                    </ul>
                    <ul className="navbar-nav search-right mt-lg-0 mt-2">
                        <li className="nav-item mr-2" title="Search"><a href="#search" className="search-search">
                                <span className="fas fa-search" aria-hidden="true"></span></a></li>
                        <li className="nav-item mx-lg-4"><a href="" className="phone-btn btn-white d-none d-lg-block btn-style ms-2"><span className="fas fa-user me-2" aria-hidden="true"></span> User Login</a></li>
                    </ul>

                    {/* //toggle switch for light and dark theme */}
                    {/* search popup */}
                    <div id="search" className="w3lpop-overlay">
                        <div className="w3lpopup">
                            <form action="#formsearch" method="GET" className="d-flex">
                                <input type="search" placeholder="Search.." name="search" required="required" autofocus/>
                                <button type="submit"><span className="fas fa-search"></span></button>
                                <a className="close" href="#formsearch">&times;</a>
                            </form>
                        </div>
                    </div>
                    {/* /search popup */}
                </div>
                {/* toggle switch for light and dark theme */}
                <div className="mobile-position">
                <nav class="navigation">
                        <div class="theme-switch-wrapper">
                            <label class="theme-switch" for="checkbox">
                                <input type="checkbox" id="checkbox"/>
                                <div class="mode-container">
                                    <i class="gg-sun"></i>
                                    <i class="gg-moon"></i>
                                </div>
                            </label>
                        </div>
                    </nav>
                </div>
                {/* //toggle switch for light and dark theme */}
            </nav>
        </div>
    </header>
    </>
  )
}

export default Header

