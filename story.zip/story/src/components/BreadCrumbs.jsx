import React from 'react'

function BreadCrumbs(props) {
  return (
    <div>
      {/* Breadcrumb */}
      <section className="w3l-about-breadcrumb">
        <div className="breadcrumb-bg breadcrumb-bg-about py-5">
          <div className="container py-lg-5 py-md-4">
            <div className="w3breadcrumb-gids text-center pt-5">
              <div className="w3breadcrumb-right">
                <h2 class="title mt-5 pt-lg-5 pt-sm-3">{props.title}</h2>
                <ul className="breadcrumbs-custom-path">
                  <li><a href="index.html">Home</a></li>
                  <li className="active"><span className="fas fa-angle-double-right mx-2"></span>{props.page}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* //Breadcrumb */}
    </div>
  )
}

export default BreadCrumbs
